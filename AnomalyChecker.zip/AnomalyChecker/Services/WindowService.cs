﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AnomalyChecker.UI;

namespace AnomalyChecker.Services
{
    public class WindowService
    {
        private LaunchWindow _launchWindow;
        private ConfigWindow _configWindow;  
        private MainWindow _mainWindow;

        public WindowService(ViewModel viewModel) 
        {

            _launchWindow = new LaunchWindow() { DataContext = viewModel };
            _configWindow = new ConfigWindow() { DataContext = viewModel };
            _mainWindow = new MainWindow() { DataContext = viewModel };
        }

        public void ShowLaunchWindow() 
        {
            _launchWindow.Show();
        }

        public void ShowConfigWindow()
        {
            _launchWindow.Close();
            _configWindow.Show();
        }

        public void ShowMainWindow()
        {
            _configWindow.Close();
            _mainWindow.Show();
        }



    }
}
